clc; clear all; close all;
addpath img
addpath src
addpath lib

